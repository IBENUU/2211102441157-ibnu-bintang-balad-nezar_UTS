import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class buah here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class Food extends Actor
{
    /**
     * Act - do whatever the buah wants to do. This method is called whenever
     * the 'Act' or 'Run' button gets pressed in the environment.
     */
    int framecounter;
    
    public void act()
    {
        framecounter++;
        if(framecounter >= 600)
        {
            getWorld().removeObject(this);
        }
        else if(isTouching(snake.class))
        {
            getWorld().removeObject(this);
        }
    }
}
