import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)

/**
 * Write a description of class tail here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class tail extends Actor
{
    int r, g, b;
    int framecounter = 0;
    int countLength = 0;
    int snakeLength= 1;
    public tail(int r, int g, int b)
    {
        this.r = r;
        this.g = g;
        this.b = b;
        getImage().setColor(new Color(r, g, b));
        getImage().fillRect(0, 0, 70, 70);
    }
    
    public void act()
    {
        framecounter++;
        if (framecounter >= 60)
        {
            getWorld().removeObject(this); 
        }
        
        
    }
}
