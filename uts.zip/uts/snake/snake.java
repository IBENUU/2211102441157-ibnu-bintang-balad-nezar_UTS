import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class snake here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */
public class snake extends Actor
{
    int speed = 2;
    int r, g, b;
    int count = 0;
    public snake(int r, int g, int b)
    {
        this.r = r;
        this.g = g;
        this.b = b;
        getImage().setColor(new Color(r, g, b));
        getImage().fillRect(0, 0, 70, 70);
        
        
    }
    
    public void act()
    {
        count++;
        getWorld().addObject(new tail(r, g, b), getX(), getY());
        move(speed);
        if(Greenfoot.isKeyDown("w")){
            setRotation(270);
            
        }
        if(Greenfoot.isKeyDown("s")){
            setRotation(90);
            
        }
        if(Greenfoot.isKeyDown("d")){
            setRotation(0);
            
        }
        if(Greenfoot.isKeyDown("a")){
            setRotation(180);
            
        }
        eatFood();
    }
    
    public void eatFood()
    {
        if(isTouching(Food.class))
        {
            bg bg = (bg) getWorld();
            bg.score.addScore();
            bg.addFood();
        }
    }
    
    
    
    
}
