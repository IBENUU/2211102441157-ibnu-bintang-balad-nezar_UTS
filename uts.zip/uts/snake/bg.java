import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.List;
/**
 * Write a description of class MyWorld here.
 * 
 * @author (your name) 
 * @version (a version number or a date)
 */


public class bg extends World
{
    snake snake;
    /**
     * Constructor for objects of class MyWorld.
     * 
     */
    int framecounter;
    public Score score = new Score();
    public bg()
    {    
        // Create a new world with 600x400 cells with a cell size of 1x1 pixels.
        super(700, 600, 1); 
        prepare();
    }
    
    private void prepare()
    {
        snake = new snake(0, 200, 0);
        addObject(snake,350,350);
        addObject(score,54,36);
        score.setLocation(66,21);
        addFood();
        YouLose youLose = new YouLose();
        addObject(youLose,330,264);
        youLose.setLocation(362,348);
        youLose.setLocation(363,348);
        youLose.setLocation(384,363);
        removeObject(youLose);
    }
    
    public void act()
    {
        framecounter++;
        if(framecounter > 600)
        {
            addFood();
        }
        
    }
    
    public void addFood()
    {
        addObject(new Food(), Greenfoot.getRandomNumber(getWidth()-1), Greenfoot.getRandomNumber(getHeight()-1));
        framecounter = 0;
    }
    
    

}
